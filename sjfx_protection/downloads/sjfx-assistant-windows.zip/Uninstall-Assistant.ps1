﻿#Requires -RunAsAdministrator
param()
$ErrorActionPreference='Stop'
$userSid=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value
$dir=Join-Path $env:ProgramData ('SJFX\FileProtection\'+$userSid)
$config=Get-Content -LiteralPath (Join-Path $dir 'install.json') -Raw|ConvertFrom-Json
$common='--server "'+$config.server+'" --data "'+$config.data+'"'
if($config.server.StartsWith('http:')){$common+=' --allow-http'}
$check=Start-Process -FilePath $config.exe -ArgumentList ($common+' --check-uninstall') -WindowStyle Hidden -Wait -PassThru
if($check.ExitCode -ne 0){throw '请先在 SJFX 文件保护页撤销全部文件处置，再卸载助手'}
Stop-ScheduledTask -TaskName 'SJFX File Protection'
$listener=Get-NetTCPConnection -LocalAddress 127.0.0.1 -LocalPort 18765 -State Listen -ErrorAction SilentlyContinue
if($listener){
 $child=Get-Process -Id $listener.OwningProcess -ErrorAction Stop
 if($child.Path -ne $config.exe){throw '监听端口的进程不是本助手，已保留安装，不停止其他进程'}
 Stop-Process -Id $child.Id -Force
 $child.WaitForExit(10000)|Out-Null
}
$restore=Start-Process -FilePath $config.exe -ArgumentList ($common+' --restore-audit') -WindowStyle Hidden -Wait -PassThru
if($restore.ExitCode -ne 0){throw '文件审计恢复失败，已保留安装和备份。请检查助手日志后重试'}
Unregister-ScheduledTask -TaskName 'SJFX File Protection' -Confirm:$false
Write-Host '助手已停用，已恢复能安全核对的文件审计权限。程序、事件库和策略备份保留。'
Write-Host '为避免关闭其他软件依赖的审计，卸载不自动修改系统审计策略。原值保存在 audit-policy-backup.json，可由管理员核对后恢复。'
