﻿#Requires -RunAsAdministrator
param([string]$Server='http://100.120.119.161:18000',[switch]$WithoutAccessAudit)
$ErrorActionPreference='Stop'
$uri=[Uri]$Server
if($uri.Scheme -notin @('http','https') -or $uri.UserInfo -or $uri.AbsolutePath -ne '/' -or $uri.Query -or $uri.Fragment){throw '请填写 SJFX 网站根地址'}
$Server=$uri.GetLeftPart([UriPartial]::Authority)
$taskName='SJFX File Protection'
$userSid=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value
$dir=Join-Path $env:ProgramData ('SJFX\FileProtection\'+$userSid)
$data=Join-Path $dir 'state'
$exe=Join-Path $dir 'sjfx-assistant.exe'
$existing=Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
if($existing){throw '助手已安装。请先在保护页恢复所有处置，再使用卸载脚本移除旧版。'}
$source=Join-Path $PSScriptRoot 'sjfx-assistant.exe'
if(-not(Test-Path -LiteralPath $source)){throw '安装包缺少助手程序'}
$expected=(Get-Content -LiteralPath (Join-Path $PSScriptRoot 'sha256.txt') -Raw).Trim().Split(' ')[0]
if((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -ne $expected){throw '助手程序与安装包校验值不一致'}
New-Item -ItemType Directory -Path $dir -Force|Out-Null
$acl=New-Object Security.AccessControl.DirectorySecurity
$acl.SetAccessRuleProtection($true,$false)
foreach($sid in @($userSid,'S-1-5-18','S-1-5-32-544')){
 $identity=New-Object Security.Principal.SecurityIdentifier($sid)
 $rule=New-Object Security.AccessControl.FileSystemAccessRule($identity,'FullControl','ContainerInherit,ObjectInherit','None','Allow')
 $acl.AddAccessRule($rule)
}
Set-Acl -LiteralPath $dir -AclObject $acl
New-Item -ItemType Directory -Path $data -Force|Out-Null
Copy-Item -LiteralPath $source -Destination $exe
$arguments='--server "'+$Server+'" --data "'+$data+'"'
if($uri.Scheme -eq 'http'){$arguments+=' --allow-http'}
if(-not $WithoutAccessAudit){$arguments+=' --access-audit'}
if(-not $WithoutAccessAudit){
  $policyProcess=Start-Process -FilePath $exe -ArgumentList ($arguments+' --enable-audit-policy') -WindowStyle Hidden -PassThru -Wait
  if($policyProcess.ExitCode -ne 0){throw '无法备份并启用 Windows 文件系统审计策略'}
}
# Use the Windows launcher for a Unicode user-profile path. Keep the parent alive
# so Task Scheduler can observe the helper's real exit code and restart it.
$launcher=Join-Path $dir 'Launch-Assistant.ps1'
@'
$ErrorActionPreference='Stop'
$config=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'install.json') -Raw|ConvertFrom-Json
$arguments='--server "'+$config.server+'" --data "'+$config.data+'"'
if($config.server.StartsWith('http:')){$arguments+=' --allow-http'}
if($config.accessAudit){$arguments+=' --access-audit'}
try {
 $child=Start-Process -FilePath $config.exe -ArgumentList $arguments -WorkingDirectory $PSScriptRoot -WindowStyle Hidden -Wait -PassThru
 exit $child.ExitCode
} catch {
 $_.Exception.Message|Add-Content -LiteralPath (Join-Path $config.data 'launcher.log') -Encoding UTF8
 exit 1
}
'@ | Set-Content -LiteralPath $launcher -Encoding UTF8
@{server=$Server;data=$data;exe=$exe;accessAudit=(-not $WithoutAccessAudit)}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $dir 'install.json') -Encoding UTF8
$powershell=Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
$launchCommand="& (Join-Path `$env:ProgramData 'SJFX\FileProtection\$userSid\Launch-Assistant.ps1')"
$encodedLaunch=[Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($launchCommand))
$action=New-ScheduledTaskAction -Execute $powershell -Argument ('-NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy RemoteSigned -EncodedCommand '+$encodedLaunch) -WorkingDirectory $env:WINDIR
$user=[Security.Principal.WindowsIdentity]::GetCurrent().Name
$trigger=New-ScheduledTaskTrigger -AtLogOn -User $user
$principal=New-ScheduledTaskPrincipal -UserId $user -LogonType Interactive -RunLevel Highest
$settings=New-ScheduledTaskSettingsSet -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -MultipleInstances IgnoreNew
Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Description '仅监视用户在 SJFX 文件保护页关联的资料'|Out-Null
Start-ScheduledTask -TaskName $taskName
$ready=$false
for($attempt=0;$attempt -lt 15;$attempt++){
 try {
  $status=Invoke-RestMethod -Uri 'http://127.0.0.1:18765/status' -Method Post -Headers @{Origin=$Server;'X-SJFX-Client'='1'} -ContentType 'application/json' -Body '{}' -TimeoutSec 2
  if($status.ok){$ready=$true;break}
 }catch{}
 Start-Sleep -Seconds 1
}
if(-not $ready){throw '助手已注册，但未通过启动检查。请检查计划任务结果及状态目录中的 assistant.log、launcher.log。'}
Write-Host ('助手已启动并通过连接检查。请登录 '+$Server+'/protection，绑定助手并选择本地资料目录。')
